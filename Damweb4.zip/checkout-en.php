<?php
session_start();
?>
<!DOCTYPE html>
<html lang="en">

  <head>

    <meta charset="utf-8">
    	<link rel="apple-touch-icon-precomposed" sizes="57x57" href="favicon/apple-touch-icon-57x57.png" />
<link rel="apple-touch-icon-precomposed" sizes="114x114" href="favicon/apple-touch-icon-114x114.png" />
<link rel="apple-touch-icon-precomposed" sizes="72x72" href="favicon/apple-touch-icon-72x72.png" />
<link rel="apple-touch-icon-precomposed" sizes="144x144" href="favicon/apple-touch-icon-144x144.png" />
<link rel="apple-touch-icon-precomposed" sizes="60x60" href="favicon/apple-touch-icon-60x60.png" />
<link rel="apple-touch-icon-precomposed" sizes="120x120" href="favicon/apple-touch-icon-120x120.png" />
<link rel="apple-touch-icon-precomposed" sizes="76x76" href="favicon/apple-touch-icon-76x76.png" />
<link rel="apple-touch-icon-precomposed" sizes="152x152" href="favicon/apple-touch-icon-152x152.png" />
<link rel="icon" type="image/png" href="favicon.ico" />
<meta name="application-name" content="&nbsp;"/>
<meta name="msapplication-TileColor" content="#FFFFFF" />
<meta name="msapplication-TileImage" content="favicon/mstile-144x144.png" />
<meta name="msapplication-square70x70logo" content="favicon/mstile-70x70.png" />
<meta name="msapplication-square150x150logo" content="favicon/mstile-150x150.png" />
<meta name="msapplication-wide310x150logo" content="favicon/mstile-310x150.png" />
<meta name="msapplication-square310x310logo" content="favicon/mstile-310x310.png" />
<meta property="og:type"  content="website" />
<meta property="og:title"  content="Damweb" />
<meta property="og:description" content="Secure website design and development">
<meta property="fb:app_id" content='763669451252283'>
<meta property="og:image"  content="https://damweb.ca/assets/images/logo-fr.png">
<meta property="og:url" content="https://damweb.ca/checkout-en.php" >
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
<meta name="Description" CONTENT="Need a safe and secure website? Need to secure your own site? We're here for you! Thanks to our knowledge of encryption and several web languages, Damweb will be happy to develop your site and / or make it more secure.">
    <meta name="author" content="Damweb">
    <link href="https://fonts.googleapis.com/css?family=Poppins:100,200,300,400,500,600,700,800,900&display=swap" rel="stylesheet">
    <title>Check Out | Damweb secure web designer</title>

    <!-- Bootstrap core CSS -->
    <link href="vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">

    <!-- Additional CSS Files -->
    <link rel="stylesheet" href="assets/css/fontawesome.css">
    <link rel="stylesheet" href="assets/css/templatemo-finance-business.css">
    <link rel="stylesheet" href="assets/css/owl.css">
    <style>
.column5s {
  float: left;
  width: 99%;
  padding: 8px;
}
.pric5e {
  list-style-type: none;
  border: 1px solid #eee;
  margin: 0;
  padding: 0;
  -webkit-transition: 0.3s;
  transition: 0.3s;
  }
.pric5e:hover {
  box-shadow: 0 8px 12px 0 rgba(0,0,0,0.2)
}
.pric5e .heade5r {
  background-color: #111;
  color: white;
  font-size: 25px;
}
.pric5e li {
  border-bottom: 1px solid #eee;
  padding: 20px;
  text-align: center;
}
.pric5e .gre5y {
  background-color: #eee;
  font-size: 20px;
}
  .butto5n {
  background-color: #4CAF50;
  border: none;
  color: white;
  padding: 10px 25px;
  text-align: center;
  text-decoration: none;
  font-size: 18px;
}
.select-css {
  display: block;
  font-size: 16px;
  font-family: sans-serif;
  font-weight: 700;
  color: #444;
  line-height: 1.3;
  padding: .6em 1.4em .5em .8em;
  width: 100%;
  max-width: 100%; 
  box-sizing: border-box;
  margin: 0;
  border: 1px solid #aaa;
  box-shadow: 0 1px 0 1px rgba(0,0,0,.04);
  border-radius: .5em;
  -moz-appearance: none;
  -webkit-appearance: none;
  appearance: none;
  background-color: #fff;
  background-image: url('data:image/svg+xml;charset=US-ASCII,%3Csvg%20xmlns%3D%22http%3A%2F%2Fwww.w3.org%2F2000%2Fsvg%22%20width%3D%22292.4%22%20height%3D%22292.4%22%3E%3Cpath%20fill%3D%22%23007CB2%22%20d%3D%22M287%2069.4a17.6%2017.6%200%200%200-13-5.4H18.4c-5%200-9.3%201.8-12.9%205.4A17.6%2017.6%200%200%200%200%2082.2c0%205%201.8%209.3%205.4%2012.9l128%20127.9c3.6%203.6%207.8%205.4%2012.8%205.4s9.2-1.8%2012.8-5.4L287%2095c3.5-3.5%205.4-7.8%205.4-12.8%200-5-1.9-9.2-5.5-12.8z%22%2F%3E%3C%2Fsvg%3E'),
    linear-gradient(to bottom, #ffffff 0%,#e5e5e5 100%);
  background-repeat: no-repeat, repeat;
  background-position: right .7em top 50%, 0 0;
  background-size: .65em auto, 100%;
}
.select-css::-ms-expand {
  display: none;
}
.select-css:hover {
  border-color: #888;
}
.select-css:focus {
  border-color: #aaa;
  box-shadow: 0 0 1px 3px rgba(59, 153, 252, .7);
  box-shadow: 0 0 0 3px -moz-mac-focusring;
  color: #222; 
  outline: none;
}
.select-css option {
  font-weight:normal;
}
*[dir="rtl"] .select-css, :root:lang(ar) .select-css, :root:lang(iw) .select-css {
  background-position: left .7em top 50%, 0 0;
  padding: .6em .8em .5em 1.4em;
}
.select-css:disabled, .select-css[aria-disabled=true] {
  color: graytext;
  background-image: url('data:image/svg+xml;charset=US-ASCII,%3Csvg%20xmlns%3D%22http%3A%2F%2Fwww.w3.org%2F2000%2Fsvg%22%20width%3D%22292.4%22%20height%3D%22292.4%22%3E%3Cpath%20fill%3D%22graytext%22%20d%3D%22M287%2069.4a17.6%2017.6%200%200%200-13-5.4H18.4c-5%200-9.3%201.8-12.9%205.4A17.6%2017.6%200%200%200%200%2082.2c0%205%201.8%209.3%205.4%2012.9l128%20127.9c3.6%203.6%207.8%205.4%2012.8%205.4s9.2-1.8%2012.8-5.4L287%2095c3.5-3.5%205.4-7.8%205.4-12.8%200-5-1.9-9.2-5.5-12.8z%22%2F%3E%3C%2Fsvg%3E'),
    linear-gradient(to bottom, #ffffff 0%,#e5e5e5 100%);
}
.select-css:disabled:hover, .select-css[aria-disabled=true] {
  border-color: #aaa;
}
</style>
  </head>

  <body>

    <!-- ***** Preloader Start ***** -->
    <div id="preloader">
        <div class="jumper">
            <div></div>
            <div></div>
            <div></div>
        </div>
    </div>  
    <!-- ***** Preloader End ***** -->

    <!-- Header -->
    
    <header class="">
      <nav class="navbar navbar-expand-lg">
        <div class="container">
          <a class="navbar-brand" href="index.php"><h2>Damweb</h2></a>
            <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarResponsive" aria-controls="navbarResponsive" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
          </button>
          <div class="collapse navbar-collapse" id="navbarResponsive">
            <ul class="navbar-nav ml-auto">
              <li class="nav-item">
                <a class="nav-link" href="index-en.php">Home
                </a>
              
                	           <li class="nav-item">
                <a class="nav-link" href="services-en.php">Our Services</a>
              </li>
                
                </li>
              <li class="nav-item ">
                <a class="nav-link" href="contact-en.php">Contact Us</a>
              </li>
   
              <li class="nav-item">
                <a class="nav-link" href="services-fr.php">Fran&ccedil;ais</a>
              </li>
            </ul>
          </div>
        </div>
      </nav>
    </header>

    <!-- Page Content -->
    <!-- Banner Starts Here -->
    <div class=" header-text" id="top">
        <div class="Modern-Slider">
        </div>
    </div>
    	    <!-- Banner Ends Here -->
    	
     <div class="page-heading header-text">
      <div class="container">
        <div class="row">
          <div class="col-md-12">
            <h1>Check Out</h1>
            <span></span>
          </div>
        </div>
      </div>
    </div>
 
          		 <div id="totHide3" style="" class="container"><br><br>
            		 	<div class="section-heading">
            		 		<?php
            		 		if($_POST['typo'] == ''){
            		 		echo '';}else{echo "<em>Site of type </em>". $_POST['typo'];}
            		 		?>
            		<h2><em><?php
            		echo $_POST['inExtra1'];
            		?></em> package</h2>For a total of  
            		<a> <?php
            		if($_POST['cashEx'] == ""){
            		echo $_POST['inExtra2'];}else{
            		echo $_POST['cashEx'] + $_POST['inExtra2'];}
            		?>,00 $<br></a><br>
            				<h5>
            			The package <em><?php
            		echo $_POST['inExtra1'];
            		?></em> Include: </h5>
            		<?php
            		echo $_POST['inExtra3'];
            		?><br><br>
            			
            			
            		<div id="smart-button-container">
      <div style="text-align: center;"><div id="paypal-button-container"></div></div></div>
  <script src="https://www.paypal.com/sdk/js?client-id=sb&currency=CAD" data-sdk-integration-source="button-factory"></script>  
  <script>function initPayPalButton() {
      paypal.Buttons({style: {shape: 'pill',color: 'black',layout: 'vertical',label: 'paypal',},
        createOrder: function(data, actions) {
          return actions.order.create({purchase_units: [{"description":"<?php
          echo "CompName: ".$_POST['compName']." ";
          ?><?php
          if($_POST['specialName'] == ""){echo "";}else{
          echo "Special: ".$_POST['specialName']." ";}
          ?>Forfait : <?php
            		echo $_POST['inExtra1']."(".$_POST['typo'].")";
            		?>","amount":{"currency_code":"CAD","value":<?php
            		if($_POST['cashEx'] == ""){
            		echo $_POST['inExtra2'];}else{
            		echo $_POST['cashEx'] + $_POST['inExtra2'];}
            		?>}}]});},
        onApprove: function(data, actions) {
          return actions.order.capture().then(function(details) {
            alert('Transaction completed by ' + details.payer.name.given_name + '!');
          });},onError: function(err) {console.log(err);} }).render('#paypal-button-container');}initPayPalButton();
  </script></div></div>
    
         <button onclick="window.location = 'services-fr.php'" style="border-radius:20%" class="border-button">Retour</button>

    
    <div class="sub-footer">
      <div class="container">
        <div class="row">
          <div class="col-md-12">
            <p>Propuls&eacute; par Damweb | <?php
      echo date("Y");      
            ?></a></p> 
                     <ul class="social-icons">
              <li><a href="https://twitter.com/damweb_ca"><i class="fa fa-twitter"></i></a></li>
              <li><a href="https://www.linkedin.com/events/damweb6764568766647951360"><i class="fa fa-linkedin"></i></a></li>
              <li><a href="https://www.facebook.com/damweb.info/"><i class="fa fa-facebook"></i></a></li>
              <li><a href="mailto:damweb.info@gmail.com"><i class="fa fa-google"></i></a></li>
              <li><a href="https://www.instagram.com/damweb.ca"><i class="fa fa-instagram"></i></a></li>
            </ul>
          </div>
        </div>
      </div>
    </div>

    <!-- Bootstrap core JavaScript -->
    <script src="vendor/jquery/jquery.min.js"></script>
    <script src="vendor/bootstrap/js/bootstrap.bundle.min.js"></script>

    <!-- Additional Scripts -->
    <script src="assets/js/custom.js"></script>
    <script src="assets/js/owl.js"></script>
    <script src="assets/js/slick.js"></script>
    <script src="assets/js/accordions.js"></script>

    <script language = "text/Javascript"> 
      cleared[0] = cleared[1] = cleared[2] = 0; //set a cleared flag for each field
      function clearField(t){                   //declaring the array outside of the
      if(! cleared[t.id]){                      // function makes it static and global
          cleared[t.id] = 1;  // you could use true and false, but that's more typing
          t.value='';         // with more chance of typos
          t.style.color='#fff';
          }
      }
    </script>
    
    
    
<script>
	var checkvalue = document.getElementById('check_amount');
	var li_hide = document.getElementById('li_hide');
	var totHide1 = document.getElementById('totHide1');
	var totHide2 = document.getElementById('totHide2');
	var totHide3 = document.getElementById('totHide3');
	function checkprice1(price){
	li_hide.style = "";
	totHide1.style = '';
	totHide2.style = 'display:none';
	totHide3.style = 'display:none';
	checkvalue.click();
	checkvalue.innerHTML = price + ',00$<i class="fa fa-angle-right"></i>';
	}
	
	function checkprice2(price){
	li_hide.style = "";
	totHide1.style = 'display:none';
	totHide2.style = '';
	totHide3.style = 'display:none';
	checkvalue.click();
	checkvalue.innerHTML = price + ',00$<i class="fa fa-angle-right"></i>';
	}
	
	function checkprice3(price){
	li_hide.style = "";
	totHide1.style = 'display:none';
	totHide2.style = 'display:none';
	totHide3.style = '';
	checkvalue.click();
	checkvalue.innerHTML = price + ',00$<i class="fa fa-angle-right"></i>';
	}
	</script>
  </body>
</html>