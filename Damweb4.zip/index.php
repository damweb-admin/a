<?php
session_start();
$_SESSION['on'] = "on";
header('Location: index-fr.php');
?>