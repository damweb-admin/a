<?php
session_start();
$_SESSION['on'] = "on";
header('Location: index-fr.php');
?>

<html lang="fr">

  <head>
  		
  	<meta http-equiv='refresh' content='5;url=index-fr.php' />
    	<link rel="apple-touch-icon-precomposed" sizes="57x57" href="favicon/apple-touch-icon-57x57.png" />
<link rel="apple-touch-icon-precomposed" sizes="114x114" href="favicon/apple-touch-icon-114x114.png" />
<link rel="apple-touch-icon-precomposed" sizes="72x72" href="favicon/apple-touch-icon-72x72.png" />
<link rel="apple-touch-icon-precomposed" sizes="144x144" href="favicon/apple-touch-icon-144x144.png" />
<link rel="apple-touch-icon-precomposed" sizes="60x60" href="favicon/apple-touch-icon-60x60.png" />
<link rel="apple-touch-icon-precomposed" sizes="120x120" href="favicon/apple-touch-icon-120x120.png" />
<link rel="apple-touch-icon-precomposed" sizes="76x76" href="favicon/apple-touch-icon-76x76.png" />
<link rel="apple-touch-icon-precomposed" sizes="152x152" href="favicon/apple-touch-icon-152x152.png" />
<link rel="icon" type="image/png" href="favicon.ico" />
<meta name="application-name" content="&nbsp;"/>
<meta name="msapplication-TileColor" content="#FFFFFF" />
<meta name="msapplication-TileImage" content="favicon/mstile-144x144.png" />
<meta name="msapplication-square70x70logo" content="favicon/mstile-70x70.png" />
<meta name="msapplication-square150x150logo" content="favicon/mstile-150x150.png" />
<meta name="msapplication-wide310x150logo" content="favicon/mstile-310x150.png" />
<meta name="msapplication-square310x310logo" content="favicon/mstile-310x310.png" />
<meta property="og:type"  content="website" />
<meta property="og:title"  content="Damweb" />
<meta property="og:description" content="Conception et d&eacute;veloppement de site Web s&eacute;curis&eacute; ">
<meta property="fb:app_id" content='763669451252283'>
<meta property="og:image"  content="https://damweb.ca/assets/images/logo-fr.png">
<meta property="og:url" content="https://damweb.ca/index.php" >
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
<meta name="Description" CONTENT="Besoin d'un site Web s&ucirc;r et s&eacute;curis&eacute;? Besoin de s&eacute;curiser votre propre site? Nous sommes l&agrave; pour vous! Gr&acirc;ce &agrave; notre connaissance du cryptage et de plusieurs langages Web, Damweb se fera un plaisir de d&eacute;velopper votre site et / ou de le rendre plus s&eacute;curis&eacute;.">
    <meta name="author" content="Damweb">
    <link href="https://fonts.googleapis.com/css?family=Poppins:100,200,300,400,500,600,700,800,900&display=swap" rel="stylesheet">
    <title>Damweb | Concepteur Web S&eacute;curis&eacute;</title>
    </head>
    <body>
      <a href="index-fr.php">https://damweb.ca/index-fr.php</a>
    </body>
    </html>
    