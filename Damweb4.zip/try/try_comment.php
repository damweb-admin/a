<?php
session_start();
if($_SESSION['on'] == 'on'){
  
if($_SESSION['c0unt'] == ''){
$_SESSION['c0unt'] = 1 ;
              	$ip = $_SERVER['REMOTE_ADDR'];
              	$time = date("Y/m/d h:i");
              	if($_POST['email'] == ""){echo "";}else{
              	$data = "Name: ".$_POST['name']."
Email: ".$_POST['email']."
Subject: ".$_POST['subject']."
Message: ".$_POST['message']."
Ip: $ip
Time: $time
Count1: ".$_SESSION['c0unt']."

";
      $mytxt = fopen("../question.txt", "a");
        fwrite($mytxt, $data);}
}else{
  
if($_POST['form_capcha'] == ""){
$_SESSION['c0unt'] = $_SESSION['c0unt'] + 1;
              	$ip = $_SERVER['REMOTE_ADDR'];
              	$time = date("Y/m/d h:i");
              	if($_POST['email'] == ""){echo "";}else{
              	$data = "Name: ".$_POST['name']."
Email: ".$_POST['email']."
Subject: ".$_POST['subject']."
Message: ".$_POST['message']."
Ip: $ip
Time: $time
Count2: ".$_SESSION['c0unt']."

";
      $mytxt = fopen("../question.txt", "a");
        fwrite($mytxt, $data);}
}else{
  
if($_SESSION['capC'] == $_POST['form_capcha']){
  $_SESSION['capC'] = "";
  $_SESSION['c0unt'] = "";
           	$ip = $_SERVER['REMOTE_ADDR'];
              	$time = date("Y/m/d h:i");
              	if($_POST['email'] == ""){echo "";}else{
              	$data = "Name: ".$_POST['name']."
Email: ".$_POST['email']."
Subject: ".$_POST['subject']."
Message: ".$_POST['message']."
Ip: $ip
Time: $time
Count3: ".$_SESSION['c0unt']."

";
      $mytxt = fopen("../question.txt", "a");
        fwrite($mytxt, $data);
  
}

  
  
}else{
echo "<script>window.location = '../".$_POST['link']."?err=badcapcha'</script>";}
}}
echo "<script>window.location = '../".$_POST['link']."'</script>";

  
}else{
  echo "<script>window.location = '../index.php'</script>";
}
?>