<?php
session_start();
?>

<!DOCTYPE html>
<html lang="fr">

  <head>

    <meta charset="utf-8"><?php
 if($_GET['finish'] == 1){
echo "<meta http-equiv='refresh' content='5;url=index-fr.php' />";
 }else{
 echo '';
 }
 
 ?>	<link rel="apple-touch-icon-precomposed" sizes="57x57" href="favicon/apple-touch-icon-57x57.png" />
<link rel="apple-touch-icon-precomposed" sizes="114x114" href="favicon/apple-touch-icon-114x114.png" />
<link rel="apple-touch-icon-precomposed" sizes="72x72" href="favicon/apple-touch-icon-72x72.png" />
<link rel="apple-touch-icon-precomposed" sizes="144x144" href="favicon/apple-touch-icon-144x144.png" />
<link rel="apple-touch-icon-precomposed" sizes="60x60" href="favicon/apple-touch-icon-60x60.png" />
<link rel="apple-touch-icon-precomposed" sizes="120x120" href="favicon/apple-touch-icon-120x120.png" />
<link rel="apple-touch-icon-precomposed" sizes="76x76" href="favicon/apple-touch-icon-76x76.png" />
<link rel="apple-touch-icon-precomposed" sizes="152x152" href="favicon/apple-touch-icon-152x152.png" />
<link rel="icon" type="image/png" href="favicon.ico" />
<meta name="application-name" content="&nbsp;"/>
<meta name="msapplication-TileColor" content="#FFFFFF" />
<meta name="msapplication-TileImage" content="favicon/mstile-144x144.png" />
<meta name="msapplication-square70x70logo" content="favicon/mstile-70x70.png" />
<meta name="msapplication-square150x150logo" content="favicon/mstile-150x150.png" />
<meta name="msapplication-wide310x150logo" content="favicon/mstile-310x150.png" />
<meta name="msapplication-square310x310logo" content="favicon/mstile-310x310.png" />
<meta property="og:type"  content="website" />
<meta property="og:title"  content="Damweb" />
<meta property="og:description" content="Conception et d&eacute;veloppement de site Web s&eacute;curis&eacute; ">
<meta property="fb:app_id" content='763669451252283'>
<meta property="og:image"  content="https://damweb.ca/assets/images/logo-fr.png">
<meta property="og:url" content="https://damweb.ca/checkout-fr.php" >
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
<meta name="Description" CONTENT="Besoin d'un site Web s&ucirc;r et s&eacute;curis&eacute;? Besoin de s&eacute;curiser votre propre site? Nous sommes l&agrave; pour vous! Gr&acirc;ce &agrave; notre connaissance du cryptage et de plusieurs langages Web, Damweb se fera un plaisir de d&eacute;velopper votre site et / ou de le rendre plus s&eacute;curis&eacute;.">
    <meta name="author" content="Damweb">
    <link href="https://fonts.googleapis.com/css?family=Poppins:100,200,300,400,500,600,700,800,900&display=swap" rel="stylesheet">
    <title>Check-Out | Concepteur Web S&eacute;curis&eacute; Damweb</title>

    <!-- Bootstrap core CSS -->
    <link href="vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">

    <!-- Additional CSS Files -->
    <link rel="stylesheet" href="assets/css/fontawesome.css">
    <link rel="stylesheet" href="assets/css/templatemo-finance-business.css">
    <link rel="stylesheet" href="assets/css/owl.css">
        <style>
.column5s {
  float: left;
  width: 99%;
  padding: 8px;
}
.pric5e {
  list-style-type: none;
  border: 1px solid #eee;
  margin: 0;
  padding: 0;
  -webkit-transition: 0.3s;
  transition: 0.3s;
  }
.pric5e:hover {
  box-shadow: 0 8px 12px 0 rgba(0,0,0,0.2)
}
.pric5e .heade5r {
  background-color: #111;
  color: white;
  font-size: 25px;
}
.pric5e li {
  border-bottom: 1px solid #eee;
  padding: 20px;
  text-align: center;
}
.pric5e .gre5y {
  background-color: #eee;
  font-size: 20px;
}
  .butto5n {
  background-color: #4CAF50;
  border: none;
  color: white;
  padding: 10px 25px;
  text-align: center;
  text-decoration: none;
  font-size: 18px;
}
</style>
  </head>

  <body>

    <!-- ***** Preloader Start ***** -->
    <div id="preloader">
        <div class="jumper">
            <div></div>
            <div></div>
            <div></div>
        </div>
    </div>  
    <!-- ***** Preloader End ***** -->

    <!-- Header -->
    
    <header class="">
      <nav class="navbar navbar-expand-lg">
        <div class="container">
          <a class="navbar-brand" href="index.php"><h2>Damweb</h2></a>
            <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarResponsive" aria-controls="navbarResponsive" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
          </button>
          <div class="collapse navbar-collapse" id="navbarResponsive">
            <ul class="navbar-nav ml-auto">
              <li class="nav-item">
                <a class="nav-link" href="index-fr.php">Accueil
                </a>
              
                	           <li class="nav-item">
                <a class="nav-link" href="services-fr.php">Nos services</a>
              </li>
                
                </li>
              <li class="nav-item">
                <a class="nav-link" href="contact-fr.php">Contactez-nous</a>
                       
              </li>
   
              <li class="nav-item">
                <a class="nav-link" href="services-en.php">English</a>
              </li>
            </ul>
          </div>
        </div>
      </nav>
    </header>

    <!-- Page Content -->
    <!-- Banner Starts Here -->
    <div class=" header-text" id="top">
        <div class="Modern-Slider">
        </div>
    </div>
    
    	    <!-- Banner Ends Here -->
    	
     <div class="page-heading header-text">
      <div class="container">
        <div class="row">
          <div class="col-md-12">
            <h1>Check-out</h1>
            <span></span>
          </div>
        </div>
      </div>
    </div>
 
          		 <div id="totHide3" style="" class="container"><br><br>
            		 	<div class="section-heading">
            		 		<?php
            		 		if($_POST['typo'] == ''){
            		 		echo '';}else{echo "<em>Site de type </em>". $_POST['typo'];}
            		 		?>
            		<h2>Forfait <em><?php
            		echo $_POST['inExtra1'];
            		?></em></h2>Pour un total de 
            		<a> <?php
            		if($_POST['cashEx'] == ""){
            		echo $_POST['inExtra2'];}else{
            		echo $_POST['cashEx'] + $_POST['inExtra2'];}
            		?>,00 $<br></a><br>
            				<h5>
            			Le forfait <em><?php
            		echo $_POST['inExtra1'];
            		?></em> Comprend: </h5>
            		<?php
            		echo $_POST['inExtra3'];
            		?><br><br>
            		<div id="smart-button-container">
      <div style="text-align: center;"><div id="paypal-button-container"></div></div></div>
  <script src="https://www.paypal.com/sdk/js?client-id=sb&currency=CAD" data-sdk-integration-source="button-factory"></script>  
  <script>function initPayPalButton() {
      paypal.Buttons({style: {shape: 'pill',color: 'black',layout: 'vertical',label: 'paypal',},
        createOrder: function(data, actions) {
          return actions.order.create({purchase_units: [{"description":"<?php
          echo "CompName: ".$_POST['compName']." ";
          ?><?php
          if($_POST['specialName'] == ""){echo "";}else{
          echo "Special: ".$_POST['specialName']." ";}
          ?>Forfait : <?php
            		echo $_POST['inExtra1']."(".$_POST['typo'].")";
            		?>","amount":{"currency_code":"CAD","value":<?php
            		if($_POST['cashEx'] == ""){
            		echo $_POST['inExtra2'];}else{
            		echo $_POST['cashEx'] + $_POST['inExtra2'];}
            		?>}}]});},
        onApprove: function(data, actions) {
          return actions.order.capture().then(function(details) {
            alert('Transaction completed by ' + details.payer.name.given_name + '!');
          });},onError: function(err) {console.log(err);} }).render('#paypal-button-container');}initPayPalButton();
  </script></div></div>
    
         <button onclick="window.location = 'services-fr.php'" style="border-radius:20%" class="border-button">Retour</button>

    
    <div class="sub-footer">
      <div class="container">
        <div class="row">
          <div class="col-md-12">
            <p>Propuls&eacute; par Damweb | <?php
      echo date("Y");      
            ?></a></p> 
                     <ul class="social-icons">
              <li><a href="https://twitter.com/damweb_ca"><i class="fa fa-twitter"></i></a></li>
              <li><a href="https://www.linkedin.com/events/damweb6764568766647951360"><i class="fa fa-linkedin"></i></a></li>
              <li><a href="https://www.facebook.com/damweb.info/"><i class="fa fa-facebook"></i></a></li>
              <li><a href="mailto:damweb.info@gmail.com"><i class="fa fa-google"></i></a></li>
              <li><a href="https://www.instagram.com/damweb.ca"><i class="fa fa-instagram"></i></a></li>
            </ul>
          </div>
        </div>
      </div>
    </div>

    <!-- Bootstrap core JavaScript -->
    <script src="vendor/jquery/jquery.min.js"></script>
    <script src="vendor/bootstrap/js/bootstrap.bundle.min.js"></script>

    <!-- Additional Scripts -->
    <script src="assets/js/custom.js"></script>
    <script src="assets/js/owl.js"></script>
    <script src="assets/js/slick.js"></script>
    <script src="assets/js/accordions.js"></script>

    <script language = "text/Javascript"> 
      cleared[0] = cleared[1] = cleared[2] = 0; //set a cleared flag for each field
      function clearField(t){                   //declaring the array outside of the
      if(! cleared[t.id]){                      // function makes it static and global
          cleared[t.id] = 1;  // you could use true and false, but that's more typing
          t.value='';         // with more chance of typos
          t.style.color='#fff';
          }
      }
    </script>
    
    
    
<script>
	var checkvalue = document.getElementById('check_amount');
	var li_hide = document.getElementById('li_hide');
	var totHide1 = document.getElementById('totHide1');
	var totHide2 = document.getElementById('totHide2');
	var totHide3 = document.getElementById('totHide3');
	function checkprice1(price){
	li_hide.style = "";
	totHide1.style = '';
	totHide2.style = 'display:none';
	totHide3.style = 'display:none';
	checkvalue.click();
	checkvalue.innerHTML = price + ',00$<i class="fa fa-angle-right"></i>';
	}
	
	function checkprice2(price){
	li_hide.style = "";
	totHide1.style = 'display:none';
	totHide2.style = '';
	totHide3.style = 'display:none';
	checkvalue.click();
	checkvalue.innerHTML = price + ',00$<i class="fa fa-angle-right"></i>';
	}
	
	function checkprice3(price){
	li_hide.style = "";
	totHide1.style = 'display:none';
	totHide2.style = 'display:none';
	totHide3.style = '';
	checkvalue.click();
	checkvalue.innerHTML = price + ',00$<i class="fa fa-angle-right"></i>';
	}
	</script>
	<?php include('try/chat.php');?>
  </body>
</html>