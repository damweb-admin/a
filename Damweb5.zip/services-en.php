<?php
session_start();
?>
<!DOCTYPE html>
<html lang="en">

  <head>

    <meta charset="utf-8"><?php
 if($_GET['finish'] == 1){
echo "<meta http-equiv='refresh' content='5;url=index-en.php' />";
 }else{
 echo '';
 }
 
 ?>
    	<link rel="apple-touch-icon-precomposed" sizes="57x57" href="favicon/apple-touch-icon-57x57.png" />
<link rel="apple-touch-icon-precomposed" sizes="114x114" href="favicon/apple-touch-icon-114x114.png" />
<link rel="apple-touch-icon-precomposed" sizes="72x72" href="favicon/apple-touch-icon-72x72.png" />
<link rel="apple-touch-icon-precomposed" sizes="144x144" href="favicon/apple-touch-icon-144x144.png" />
<link rel="apple-touch-icon-precomposed" sizes="60x60" href="favicon/apple-touch-icon-60x60.png" />
<link rel="apple-touch-icon-precomposed" sizes="120x120" href="favicon/apple-touch-icon-120x120.png" />
<link rel="apple-touch-icon-precomposed" sizes="76x76" href="favicon/apple-touch-icon-76x76.png" />
<link rel="apple-touch-icon-precomposed" sizes="152x152" href="favicon/apple-touch-icon-152x152.png" />
<link rel="icon" type="image/png" href="favicon.ico" />
<meta name="application-name" content="&nbsp;"/>
<meta name="msapplication-TileColor" content="#FFFFFF" />
<meta name="msapplication-TileImage" content="favicon/mstile-144x144.png" />
<meta name="msapplication-square70x70logo" content="favicon/mstile-70x70.png" />
<meta name="msapplication-square150x150logo" content="favicon/mstile-150x150.png" />
<meta name="msapplication-wide310x150logo" content="favicon/mstile-310x150.png" />
<meta name="msapplication-square310x310logo" content="favicon/mstile-310x310.png" />
<meta property="og:type"  content="website" />
<meta property="og:title"  content="Damweb" />
<meta property="og:description" content="Secure website design and development">
<meta property="fb:app_id" content='763669451252283'>
<meta property="og:image"  content="https://damweb.ca/assets/images/logo-fr.png">
<meta property="og:url" content="https://damweb.ca/services-en.php" >
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
<meta name="Description" CONTENT="Need a safe and secure website? Need to secure your own site? We're here for you! Thanks to our knowledge of encryption and several web languages, Damweb will be happy to develop your site and / or make it more secure.">
    <meta name="author" content="Damweb">
    <link href="https://fonts.googleapis.com/css?family=Poppins:100,200,300,400,500,600,700,800,900&display=swap" rel="stylesheet">
    <title>Our Services | Damweb secure web designer</title>

    <!-- Bootstrap core CSS -->
    <link href="vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">

    <!-- Additional CSS Files -->
    <link rel="stylesheet" href="assets/css/fontawesome.css">
    <link rel="stylesheet" href="assets/css/templatemo-finance-business.css">
    <link rel="stylesheet" href="assets/css/owl.css">
    <style>
.column5s {
  float: left;
  width: 99%;
  padding: 8px;
}
.pric5e {
  list-style-type: none;
  border: 1px solid #eee;
  margin: 0;
  padding: 0;
  -webkit-transition: 0.3s;
  transition: 0.3s;
  }
.pric5e:hover {
  box-shadow: 0 8px 12px 0 rgba(0,0,0,0.2)
}
.pric5e .heade5r {
  background-color: #111;
  color: white;
  font-size: 25px;
}
.pric5e li {
  border-bottom: 1px solid #eee;
  padding: 20px;
  text-align: center;
}
.pric5e .gre5y {
  background-color: #eee;
  font-size: 20px;
}
  .butto5n {
  background-color: #4CAF50;
  border: none;
  color: white;
  padding: 10px 25px;
  text-align: center;
  text-decoration: none;
  font-size: 18px;
}
.select-css {
  display: block;
  font-size: 16px;
  font-family: sans-serif;
  font-weight: 700;
  color: #444;
  line-height: 1.3;
  padding: .6em 1.4em .5em .8em;
  width: 100%;
  max-width: 100%; 
  box-sizing: border-box;
  margin: 0;
  border: 1px solid #aaa;
  box-shadow: 0 1px 0 1px rgba(0,0,0,.04);
  border-radius: .5em;
  -moz-appearance: none;
  -webkit-appearance: none;
  appearance: none;
  background-color: #fff;
  background-image: url('data:image/svg+xml;charset=US-ASCII,%3Csvg%20xmlns%3D%22http%3A%2F%2Fwww.w3.org%2F2000%2Fsvg%22%20width%3D%22292.4%22%20height%3D%22292.4%22%3E%3Cpath%20fill%3D%22%23007CB2%22%20d%3D%22M287%2069.4a17.6%2017.6%200%200%200-13-5.4H18.4c-5%200-9.3%201.8-12.9%205.4A17.6%2017.6%200%200%200%200%2082.2c0%205%201.8%209.3%205.4%2012.9l128%20127.9c3.6%203.6%207.8%205.4%2012.8%205.4s9.2-1.8%2012.8-5.4L287%2095c3.5-3.5%205.4-7.8%205.4-12.8%200-5-1.9-9.2-5.5-12.8z%22%2F%3E%3C%2Fsvg%3E'),
    linear-gradient(to bottom, #ffffff 0%,#e5e5e5 100%);
  background-repeat: no-repeat, repeat;
  background-position: right .7em top 50%, 0 0;
  background-size: .65em auto, 100%;
}
.select-css::-ms-expand {
  display: none;
}
.select-css:hover {
  border-color: #888;
}
.select-css:focus {
  border-color: #aaa;
  box-shadow: 0 0 1px 3px rgba(59, 153, 252, .7);
  box-shadow: 0 0 0 3px -moz-mac-focusring;
  color: #222; 
  outline: none;
}
.select-css option {
  font-weight:normal;
}
*[dir="rtl"] .select-css, :root:lang(ar) .select-css, :root:lang(iw) .select-css {
  background-position: left .7em top 50%, 0 0;
  padding: .6em .8em .5em 1.4em;
}
.select-css:disabled, .select-css[aria-disabled=true] {
  color: graytext;
  background-image: url('data:image/svg+xml;charset=US-ASCII,%3Csvg%20xmlns%3D%22http%3A%2F%2Fwww.w3.org%2F2000%2Fsvg%22%20width%3D%22292.4%22%20height%3D%22292.4%22%3E%3Cpath%20fill%3D%22graytext%22%20d%3D%22M287%2069.4a17.6%2017.6%200%200%200-13-5.4H18.4c-5%200-9.3%201.8-12.9%205.4A17.6%2017.6%200%200%200%200%2082.2c0%205%201.8%209.3%205.4%2012.9l128%20127.9c3.6%203.6%207.8%205.4%2012.8%205.4s9.2-1.8%2012.8-5.4L287%2095c3.5-3.5%205.4-7.8%205.4-12.8%200-5-1.9-9.2-5.5-12.8z%22%2F%3E%3C%2Fsvg%3E'),
    linear-gradient(to bottom, #ffffff 0%,#e5e5e5 100%);
}
.select-css:disabled:hover, .select-css[aria-disabled=true] {
  border-color: #aaa;
}
</style>
  </head>

  <body>

    <!-- ***** Preloader Start ***** -->
    <div id="preloader">
        <div class="jumper">
            <div></div>
            <div></div>
            <div></div>
        </div>
    </div>  
    <!-- ***** Preloader End ***** -->

    <!-- Header -->
    
    <header class="">
      <nav class="navbar navbar-expand-lg">
        <div class="container">
          <a class="navbar-brand" href="index.php"><h2>Damweb</h2></a>
            <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarResponsive" aria-controls="navbarResponsive" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
          </button>
          <div class="collapse navbar-collapse" id="navbarResponsive">
            <ul class="navbar-nav ml-auto">
              <li class="nav-item">
                <a class="nav-link" href="index-en.php">Home
                </a>
              
                	           <li class="nav-item active">
                <a class="nav-link" href="services-en.php">Our Services</a>
                       <span class="sr-only">(current)</span>
              </li>
                
                </li>
              <li class="nav-item ">
                <a class="nav-link" href="contact-en.php">Contact Us</a>
              </li>
   
              <li class="nav-item">
                <a class="nav-link" href="services-fr.php">Fran&ccedil;ais</a>
              </li>
            </ul>
          </div>
        </div>
      </nav>
    </header>

    <!-- Page Content -->
    <!-- Banner Starts Here -->
    <div class=" header-text" id="top">
        <div class="Modern-Slider">
        </div>
    </div>
    	    <!-- Banner Ends Here -->
    	
     <div class="page-heading header-text">
      <div class="container">
        <div class="row">
          <div class="col-md-12">
            <h1>Our Services</h1>
            <span>Our service and approximate prices</span>
          </div>
        </div>
      </div>
    </div>

<div id="divHide1" class="single-services">
      <div class="container">
        <div class="row" id="tabs">
          <div class="col-md-4">
            <ul>
              <li><a href='#tabs-1'>From A to Z<i class="fa fa-angle-right"></i></a></li>
            <li><a href='#tabs-2'>Secure my website<i class="fa fa-angle-right"></i></a></li>
            <li><a href='#tabs-3'>Hosting <i class="fa fa-angle-right"></i></a></li>
              <li><a href='#tabs-4' id="check_amount">00,00$<i class="fa fa-angle-right"></i></a></li>
              </ul>
          </div>
          <div class="col-md-8">
            <section class='tabs-content'>
              <article id='tabs-1'>
<div class="column5s">
  <ul class="pric5e">
    <li class="heade5r">From A to Z (230,00$) </li>
    <li class="gre5y">+ 60,00$ / month</li>
    <li>Include <b>Secure my website</b></li>
    <li>Include <b>Hosting</b></li>
    <li>Unique web pages</li>
    <li>Own algorithm for encryption</li>
    <li class="gre5y"><a onclick="checkprice1(230,60,'From A to Z')" class="butto5n">Select</a></li>
  </ul>
</div>                
  </article>
                          <article id='tabs-2'>
<div class="column5s">
  <ul class="pric5e">
    <li class="heade5r">Secure my website (180,00$)</li>
    <li class="gre5y">Protection:</li>
    <li>Mysql flaws</li>
    <li>Bruteforce</li>
    <li>Password end-to-end Encryption</li>
    
    <li class="gre5y"><a onclick="checkprice2(180,'Secure my website')" class="butto5n">Select</a></li>
  </ul>
</div>                
            </article>
                <article id='tabs-3'>
<div class="column5s">
  <ul class="pric5e">
    <li class="heade5r">Hosting</li>
    <li class="gre5y">60,00$ / month</li>
    <li>Https(SSL) Domain</li>
    <li>Dedicated Ip</li>
    <li>Firewall on desired ports</li>
    <li>DDoS protection</li>
    <li>5GB Bandwidth</li>
    <li class="gre5y"><a onclick="checkprice3(60,'Hosting')" class="butto5n">Select</a></li>
  </ul>
</div>                
            </article>
              <article id='tabs-4'>
                      <img src="assets/images/single_service_04.jpg" alt=""><form name="Form" id="Form" action="here" method='post'>
                      <div class="column5s">
  <ul class="pric5e">
    <li id="li_extra1" class="heade5r">Total</li>
    <li style='display:none' id="li_total" class="gre5y"></li>
    <li style='display:none' id="li_extra2"></li>

    <li id="butt0n2" style='display:none' class="gre5y"><a onclick="hide1ToHide2()" style="display:none"id="butt0n" class="butto5n">Continue</a></li>
  </ul>
</div>                </form>
              </article>
            <p>* Better to contact us before you pay because there may be some difference in price.</p>
            </section>
          </div>
        </div>
      </div>
    </div> 


    <div id="divHide2" style="display:none" class="callback-form">
      <div class="container">
        <div class="row">
          <div class="col-md-12">
            <div class="section-heading">
              <h2><em id="n4me"></em> Package</h2>
              <span>Answer the following questions to continue payment</span>
                     </div>
          </div>
          <div class="col-md-12">
            <div class="contact-form">
              <form id="contact" action="checkout-en.php" method="post">
      <input type="hidden" name="link" value="services-fr.php?finish=1">
                <div class="row">
                  <div class="col-lg-4 col-md-12 col-sm-12">
                    <fieldset>
                    	
                      <input name="domain" type="text" class="form-control" id="name" placeholder="Name of your compagny" required="">
                    </fieldset>
                  </div>
                  
                  <div class="col-lg-4 col-md-12 col-sm-12">
                    <fieldset>
                      <input name="special" type="text" class="form-control" id="email"  placeholder="Special request (optional)">
                    </fieldset>
                  </div>
                                 <div id="divType1" style="" class="col-lg-4 col-md-12 col-sm-12">
                    <fieldset>
                    	<h4 id="typeDescription"></h4><a id="typeDescription2"></a> 
                    		<select id="type1" name="type1" class="select-css" onchange="typeSelect()" required>
                    			<option id="cho0se1" value="">Choose a category </option>
                    			<option value="A">Type A</option>
                    			<option value="B">Type B</option>
                    			<option value="C">Type C</option>
                    				</select>
                    	</fieldset><br><br>
                  </div>
                    <div id="divType2" style="" class="col-lg-4 col-md-12 col-sm-12">
                    <fieldset>
                    	<h4 id="type2Description"></h4><a id="type2Description2"></a> 
                    		<select id="type2" name="type2" class="select-css" onchange="typeSelect2()" required>
                    			<option id="cho0se2" value="">Choose a category </option>
                    			<option value="A">Type A</option>
                    			<option value="B">Type B</option>
                    			<option value="C">Type C</option>
                    				</select>
                    	</fieldset><br><br>
                    		
                    			
                    	<input type="hidden" name="inExtra1" id="inExtra1">
    	    <input type="hidden" name="inExtra2" id="inExtra2">
    	    		    <input type="hidden" name="inExtra3" id="inExtra3">
                    			<input type="hidden" id="cashEx" name="cashEx" value="">
                    				<input type="hidden" id="typo" name="typo" value="">
                  </div>
<?php
	
	if($_SESSION['c0unt'] > 3){
	echo "<div class='col-lg-4 col-md-12 col-sm-12'><fieldset>";
	  if($_GET['err'] == 'badcapcha'){
	    echo "<p>Bad capcha</p>";
	  }else{echo "";}
echo "<img src='try/photo.php' width='103' style='border-radius: 10%;'><hr><input name='form_capcha' type='text' class='form-control' id='subject' placeholder='Enter Code' required=''>";
	}else{
	echo "";
	} ?>
                    </fieldset>
                  </div>
                  <div class="col-lg-12">
                    <fieldset>
                    	     <button type="submit" id="form-submit" class="border-button">Continue</button><br><br>
                    	  <button onclick="window.location = '';" class="border-button">Go Back</button>
                 
                    </fieldset>
                  </div>
                </div>
              </form>
            </div>
          </div>
        </div>
      </div>
    </div>
    

    
  
    <br><br><br>

    
    
    <div class="sub-footer">
      <div class="container">
        <div class="row">
          <div class="col-md-12">
            <p>Powered by Damweb | <?php
      echo date("Y");      
            ?></a></p> 
                     <ul class="social-icons">
              <li><a href="https://twitter.com/damweb_ca"><i class="fa fa-twitter"></i></a></li>
              <li><a href="https://www.linkedin.com/events/damweb6764568766647951360"><i class="fa fa-linkedin"></i></a></li>
              <li><a href="https://www.facebook.com/damweb.info/"><i class="fa fa-facebook"></i></a></li>
              <li><a href="mailto:damweb.info@gmail.com"><i class="fa fa-google"></i></a></li>
              <li><a href="https://www.instagram.com/damweb.ca"><i class="fa fa-instagram"></i></a></li>
            </ul>
          </div>
        </div>
      </div>
    </div>

    <!-- Bootstrap core JavaScript -->
    <script src="vendor/jquery/jquery.min.js"></script>
    <script src="vendor/bootstrap/js/bootstrap.bundle.min.js"></script>

    <!-- Additional Scripts -->
    <script src="assets/js/custom.js"></script>
    <script src="assets/js/owl.js"></script>
    <script src="assets/js/slick.js"></script>
    <script src="assets/js/accordions.js"></script>

    <script language = "text/Javascript"> 
      cleared[0] = cleared[1] = cleared[2] = 0; //set a cleared flag for each field
      function clearField(t){                   //declaring the array outside of the
      if(! cleared[t.id]){                      // function makes it static and global
          cleared[t.id] = 1;  // you could use true and false, but that's more typing
          t.value='';         // with more chance of typos
          t.style.color='#fff';
          }
      }
    </script>
    <script>
    	var typeDescription = document.getElementById('typeDescription');
    	var typeDescription2 = document.getElementById('typeDescription2');
    	var type2Description = document.getElementById('type2Description');
    	var type2Description2 = document.getElementById('type2Description2');
    	var divType1 = document.getElementById('divType1');
    	var divType2 = document.getElementById('divType2');
    	var type1 = document.getElementById('type1');
    	var type2 = document.getElementById('type2');
    	var typo = document.getElementById('typo');
    	var cashEx = document.getElementById('cashEx');
    	function typeSelect(){
    	if(document.getElementById('type1').value == "A") {
    	typeDescription.innerHTML = 'Type A: ';
    	typeDescription2.innerHTML = "- Basic price<br>- Basic site <br>- No new user so everyone can access the site <br>- SEO (allows Google to access your site) <br> - 13 pages maximum<br><br>";
    	typo.value = "A";
    	cashEx.value = "";
    	}
    	if(document.getElementById('type1').value == "B") {
        typeDescription.innerHTML = 'Type B: ';
        typeDescription2.innerHTML = "- 1580$ additional<br>- Professional website <br>- Login system good for ecommerce, forum, blog, social media site <br>- SEO (allows Google to access your site) <br> - 130 pages maximum<br><br>";
        typo.value = "B";
        cashEx.value = 1580;
    	}
    	if(document.getElementById('type1').value == "C") {
    	typeDescription.innerHTML = 'Type C: ';
    	typeDescription2.innerHTML = "- 7890$ additional<br>- Internal site <br>- Secure local computer network<br><br>";
    	typo.value = "C";
    	cashEx.value = 7890;
    	}
    	}
    	function typeSelect2(){
    	if(document.getElementById('type2').value == "A") {
    	type2Description.innerHTML = 'Type A: ';
    	type2Description2.innerHTML = "- Basic price<br>- Basic site <br>- No new user so everyone can access the site <br>- SEO (allows Google to access your site) <br> - 13 pages maximum<br><br>";
    	typo.value = "A";
    	cashEx.value = "";
    	}
    	if(document.getElementById('type2').value == "B") {
        type2Description.innerHTML = 'Type B: ';
        type2Description2.innerHTML = "- 1450$ additional<br>- Professional website <br>- Login system good for ecommerce, forum, blog, social media site <br>- SEO (allows Google to access your site) <br> - 130 pages maximum<br><br>";
        typo.value = "B";
        cashEx.value = 1450;
    	}
    	if(document.getElementById('type2').value == "C") {
    	type2Description.innerHTML = 'Type C: ';
    	type2Description2.innerHTML = "- 5600$ additional<br>- Internal site <br>- Secure local computer network<br><br>";
    	typo.value = "C";
    	cashEx.value = 5600;
    	}
    	}
    	
    	</script>
    
<script>
	var checkvalue = document.getElementById('check_amount');
	var liTotal = document.getElementById('li_total');
	var liExtra1 = document.getElementById('li_extra1');
	var liExtra2 = document.getElementById('li_extra2');
	var liExtra2value = document.getElementById('extra');
	var butt0n = document.getElementById('butt0n');
	var inExtra1 = document.getElementById('inExtra1');
	var n4me = document.getElementById('n4me');
	var inExtra2 = document.getElementById('inExtra2');
	var inExtra3 = document.getElementById('inExtra3');
	var divHide1 = document.getElementById('divHide1');
	var divHide2 = document.getElementById('divHide2');
	var butt0n2 = document.getElementById('butt0n2');
	var description1 = "<li>60,00$ / month</li><li>Include <em>Secure my website</em></li><li>Include <em>Hosting</em></li><li>Unique web pages</li><li>Own algorithm for encryption</li>";
	var description2 = "<li>Protection:</li><li>Mysql flaws</li><li>Bruteforce</li><li>Password end-to-end Encryption</li>";
	var description3 = "<li>60,00$ / month</li><li>Https(SSL) Domain</li><li>Dedicated Ip</li><li>Firewall on desired ports</li><li>DDoS protection</li><li>5GB Bandwidth</li>";
	var cho0se1 = document.getElementById('cho0se1');
	var cho0se2 = document.getElementById('cho0se2');
    	
	function checkprice1(pricetoadd,pricemonth,name){
	cho0se1.value = "";
	cho0se2.value = "value";
	divType1.style = "";
	divType2.style = "display:none";
	checkvalue.click();
	liTotal.style = "";
	butt0n2.style = "";
	inExtra1.value = name;
	inExtra3.value = description1;
	n4me.innerHTML = name;
	inExtra2.value = pricetoadd + pricemonth;
	butt0n.style = "";
	liExtra1.innerHTML = name;
	liTotal.innerHTML =  pricetoadd + ',00$' + ' + ' + pricemonth + ',00$ / month</li>';
	checkvalue.innerHTML = pricemonth + pricetoadd + ',00$<i class="fa fa-angle-right"></i>';
	}
	
	function checkprice2(pricetoadd,name){
	cho0se1.value = "value";
	cho0se2.value = "";
	divType1.required = false;
	divType2.required = true;
	divType1.style = "display:none";
	divType2.style = "";
	checkvalue.click();
	butt0n2.style = "";
	liExtra2.style = "display:none";
	liTotal.style = "";
	inExtra1.value = name;
	inExtra3.value = description2;
	n4me.innerHTML = name;
	inExtra2.value = pricetoadd;
	butt0n.style = "";
	liExtra1.innerHTML = name;
	liTotal.innerHTML = pricetoadd + ',00$';
	liExtra2.innerHTML = '';
	checkvalue.innerHTML = pricetoadd + ',00$<i class="fa fa-angle-right"></i>';
	}
	
	function checkprice3(pricemonth,name){
	cho0se1.value = "value";
	cho0se2.value = "value";
	cashEx.value = "";
	typo.value = "";
	divType1.required = false;
	divType2.required = false;
	divType1.style = "display:none";
	divType2.style = "display:none";
	checkvalue.click();
	butt0n2.style = "";
	liExtra2.style = "display:none";
	liTotal.style = "";
	inExtra1.value = name;
	inExtra3.value = description3;
	n4me.innerHTML = name;
	inExtra2.value = pricemonth;
	butt0n.style = "";
	liExtra1.innerHTML = name;
	liTotal.innerHTML = pricemonth + ',00$ / month';
	liExtra2.innerHTML = "";
	checkvalue.innerHTML = pricemonth + ',00$<i class="fa fa-angle-right"></i>';
	}
	function hide1ToHide2() {
	divHide1.style = "display:none";
	divHide2.style = "";
	}
	function hide2ToHide1() {
	divHide1.style = "";
	divHide2.style = "display:none";
	}
	</script>
	<?php include('try/chat.php');?>
  </body>
</html>