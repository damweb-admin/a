<?php
session_start();
if($_SESSION['on'] == 'on'){
?>

<!DOCTYPE html>
<html lang="fr">

  <head>

    <meta charset="utf-8"><?php
 if($_GET['finish'] == 1){
echo "<meta http-equiv='refresh' content='5;url=index-fr.php' />";
 }else{
 echo '';
 }
 
 ?>	<link rel="apple-touch-icon-precomposed" sizes="57x57" href="favicon/apple-touch-icon-57x57.png" />
<link rel="apple-touch-icon-precomposed" sizes="114x114" href="favicon/apple-touch-icon-114x114.png" />
<link rel="apple-touch-icon-precomposed" sizes="72x72" href="favicon/apple-touch-icon-72x72.png" />
<link rel="apple-touch-icon-precomposed" sizes="144x144" href="favicon/apple-touch-icon-144x144.png" />
<link rel="apple-touch-icon-precomposed" sizes="60x60" href="favicon/apple-touch-icon-60x60.png" />
<link rel="apple-touch-icon-precomposed" sizes="120x120" href="favicon/apple-touch-icon-120x120.png" />
<link rel="apple-touch-icon-precomposed" sizes="76x76" href="favicon/apple-touch-icon-76x76.png" />
<link rel="apple-touch-icon-precomposed" sizes="152x152" href="favicon/apple-touch-icon-152x152.png" />
<link rel="icon" type="image/png" href="favicon/favicon-196x196.png" sizes="196x196" />
<link rel="icon" type="image/png" href="favicon/favicon-96x96.png" sizes="96x96" />
<link rel="icon" type="image/png" href="favicon/favicon-32x32.png" sizes="32x32" />
<link rel="icon" type="image/png" href="favicon/favicon-16x16.png" sizes="16x16" />
<link rel="icon" type="image/png" href="favicon/favicon-128.png" sizes="128x128" />
<meta name="application-name" content="&nbsp;"/>
<meta name="msapplication-TileColor" content="#FFFFFF" />
<meta name="msapplication-TileImage" content="favicon/mstile-144x144.png" />
<meta name="msapplication-square70x70logo" content="favicon/mstile-70x70.png" />
<meta name="msapplication-square150x150logo" content="favicon/mstile-150x150.png" />
<meta name="msapplication-wide310x150logo" content="favicon/mstile-310x150.png" />
<meta name="msapplication-square310x310logo" content="favicon/mstile-310x310.png" />
<meta property="og:url" content="https://damweb.ca" />
<meta property="og:type"  content="website" />
<meta property="og:title"  content="Damweb" />
<meta property="og:description" content="Make your own website with Damweb" />
<meta property="og:image"  content="favicon.ico" />
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
<meta name="Description" CONTENT="Web conception - Conception Web - Secure your website - S&eacute;curiser votre site web - security - s&eacute;curit&eacute; - Damweb - Damweb.ca - https - ssl - SSL - TLS - tls - server - buy - buy server - buy Domain - programmeur web - programmeur de site web - achetter site internet - buy internet site - shield web - anti-ddos - anti-bruteforce - bruteforce protection - ddos protection - protection ddos - protected website - protected web - comment prot&eacute;ger mon site web - how to protect my website - protection internet">
    <meta name="author" content="Damweb">
    <link href="https://fonts.googleapis.com/css?family=Poppins:100,200,300,400,500,600,700,800,900&display=swap" rel="stylesheet">

    <title>Damweb - Nos services</title>

    <!-- Bootstrap core CSS -->
    <link href="vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">

    <!-- Additional CSS Files -->
    <link rel="stylesheet" href="assets/css/fontawesome.css">
    <link rel="stylesheet" href="assets/css/templatemo-finance-business.css">
    <link rel="stylesheet" href="assets/css/owl.css">
        <style>
.column5s {
  float: left;
  width: 99%;
  padding: 8px;
}
.pric5e {
  list-style-type: none;
  border: 1px solid #eee;
  margin: 0;
  padding: 0;
  -webkit-transition: 0.3s;
  transition: 0.3s;
  }
.pric5e:hover {
  box-shadow: 0 8px 12px 0 rgba(0,0,0,0.2)
}
.pric5e .heade5r {
  background-color: #111;
  color: white;
  font-size: 25px;
}
.pric5e li {
  border-bottom: 1px solid #eee;
  padding: 20px;
  text-align: center;
}
.pric5e .gre5y {
  background-color: #eee;
  font-size: 20px;
}
  .butto5n {
  background-color: #4CAF50;
  border: none;
  color: white;
  padding: 10px 25px;
  text-align: center;
  text-decoration: none;
  font-size: 18px;
}
</style>
  </head>

  <body>

    <!-- ***** Preloader Start ***** -->
    <div id="preloader">
        <div class="jumper">
            <div></div>
            <div></div>
            <div></div>
        </div>
    </div>  
    <!-- ***** Preloader End ***** -->

    <!-- Header -->
    
    <header class="">
      <nav class="navbar navbar-expand-lg">
        <div class="container">
          <a class="navbar-brand" href="index.php"><h2>Damweb</h2></a>
            <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarResponsive" aria-controls="navbarResponsive" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
          </button>
          <div class="collapse navbar-collapse" id="navbarResponsive">
            <ul class="navbar-nav ml-auto">
              <li class="nav-item">
                <a class="nav-link" href="index-fr.php">Accueil
                </a>
              
                	           <li class="nav-item active">
                <a class="nav-link" href="services-fr.php">Nos services</a>
              </li>
                
                </li>
              <li class="nav-item">
                <a class="nav-link" href="contact-fr.php">Contactez-nous</a>
                       
              </li>
   
              <li class="nav-item">
                <a class="nav-link" href="services-en.php">English</a>
              </li>
            </ul>
          </div>
        </div>
      </nav>
    </header>

    <!-- Page Content -->
    <!-- Banner Starts Here -->
    <div class=" header-text" id="top">
        <div class="Modern-Slider">
        </div>
    </div>
    
    	    <!-- Banner Ends Here -->
    	
     <div class="page-heading header-text">
      <div class="container">
        <div class="row">
          <div class="col-md-12">
            <h1>Nos services</h1>
            <span>Notre service et prix approximatifs</span>
          </div>
        </div>
      </div>
    </div>
 

<div id="divHide1" class="single-services">
      <div class="container">
        <div class="row" id="tabs">
          <div class="col-md-4">
            <ul>
              <li><a href='#tabs-1'>De A &agrave; Z<i class="fa fa-angle-right"></i></a></li>
            <li><a href='#tabs-2'>S&eacute;curiser mon site web<i class="fa fa-angle-right"></i></a></li>
            <li><a href='#tabs-3'>H&eacute;bergement <i class="fa fa-angle-right"></i></a></li>
              <li><a href='#tabs-4' id="check_amount">00,00$<i class="fa fa-angle-right"></i></a></li>
              </ul>
          </div>
          <div class="col-md-8">
            <section class='tabs-content'>
              <article id='tabs-1'>
<div class="column5s">
  <ul class="pric5e">
    <li class="heade5r">De A à Z (230,00$) </li>
    <li class="gre5y">+ 60,00$ / mois</li>
    <li>Inclue <b>S&eacute;curiser mon site web</b></li>
    <li>Inclue <b>H&eacute;bergement</b></li>
    <li>Page web unique</li>
    <li>Propre algorithme de cryptage</li>
    <li class="gre5y"><a onclick="checkprice1(230,60,'De A &agrave; Z')" class="butto5n">Selectionner</a></li>
  </ul>
</div>                
  </article>
                          <article id='tabs-2'>
<div class="column5s">
  <ul class="pric5e">
    <li class="heade5r">S&eacute;curiser mon site web (180,00$)</li>
    <li class="gre5y">Protection:</li>
  <li> Failles de Mysql </li>
    <li> Bruteforce </li>
    <li> Chiffrement de mot de passe de bout en bout </li>
    
    <li class="gre5y"><a onclick="checkprice2(180,'S&eacute;curiser mon site web')" class="butto5n">Selectionner</a></li>
  </ul>
</div>                
            </article>
                <article id='tabs-3'>
<div class="column5s">
  <ul class="pric5e">
    <li class="heade5r">H&eacute;bergement/li>
    <li class="gre5y">60,00$ / mois</li>
<li> Domaine Https (SSL)</li>
<li> Ip d&eacute;di&eacute; </li>
<li> Pare-feu sur les ports souhait&eacute;s </li>
<li> Protection DDoS </li>
<li> Bande passante de 5 Go </li>
    <li class="gre5y"><a onclick="checkprice3(60,'H&eacute;bergement')" class="butto5n">Selectionner</a></li>
  </ul>
</div>                
            </article>
              <article id='tabs-4'>
                      <img src="assets/images/single_service_04.jpg" alt=""><form name="Form" id="Form" action="here" method='post'>
                      <div class="column5s">
  <ul class="pric5e">
    <li id="li_extra1" class="heade5r">Total</li>
    <li style='display:none' id="li_total" class="gre5y"></li>
    <li style='display:none' id="li_extra2"></li>

    <li id="butt0n2" style='display:none' class="gre5y"><a onclick="hide1ToHide2()" style="display:none"id="butt0n" class="butto5n">Continuer</a></li>
  </ul>
</div>                </form>
              </article>
            </section>
          </div>
        </div>
      </div>
    </div> 
    

    <div id="divHide2" style="display:none" class="callback-form">
      <div class="container">
        <div class="row">
          <div class="col-md-12">
            <div class="section-heading">
              <h2>Forfait <em id="n4me"></em></h2>
              <span> Nous allons vous contacter </span><span>pour le paiement </span>
                     </div>
          </div>
          <div class="col-md-12">
            <div class="contact-form">
              <form id="contact" action="try/try_comment.php" method="post">
      <input type="hidden" name="link" value="services-fr.php?finish=1">
                <div class="row">
                  <div class="col-lg-4 col-md-12 col-sm-12">
                    <fieldset>
                    	    <input type="hidden" name="inExtra1" id="inExtra1">
    	    <input type="hidden" name="inExtra2" id="inExtra2">
    	    	    <input type="hidden" name="inExtra3" id="inExtra3">
                      <input name="name" type="text" class="form-control" id="name" placeholder="Nom Complet" required="">
                    </fieldset>
                  </div>
                  <div class="col-lg-4 col-md-12 col-sm-12">
                    <fieldset>
                      <input name="email" type="email" class="form-control" id="email"  placeholder="Addresse Email" required="">
                    </fieldset>
                  </div>
                  <div class="col-lg-4 col-md-12 col-sm-12">
                    <fieldset>
                      <input name="phone" type="text" class="form-control" id="subject" placeholder="Num&eacute;ro De T&eacute;l&eacute;phone" required="">
                    </fieldset>
                  </div>
            
<?php
	
	if($_SESSION['c0unt'] > 3){
	echo "<div class='col-lg-4 col-md-12 col-sm-12'><fieldset>";
	  if($_GET['err'] == 'badcapcha'){
	    echo "<p>Bad capcha</p>";
	  }else{echo "";}
echo "<img src='try/photo.php' width='103' style='border-radius: 10%;'><hr><input name='form_capcha' type='text' class='form-control' id='subject' placeholder='Entrez le code' required=''>";
	}else{
	echo "";
	} ?>
                    </fieldset>
                  </div>
                  <div class="col-lg-12">
                    <fieldset>
                      <button type="submit" id="form-submit" class="border-button">Continuer</button><br><br>
                      	  <button onclick="hide2ToHide1()" class="border-button">Retour</button>
                    </fieldset>
                  </div>
                </div>
              </form>
            </div>
          </div>
        </div>
      </div>
    </div>
 
    
    
    
        <div id="divHide3" style="display:none" class="callback-form">
      <div class="container">
        <div class="row">
          <div class="col-md-12">
            <div class="section-heading">
              <h2>Merci de nous avoir <em>contact&eacute;s</em></h2>
              <span> nous vous r&eacute;pondrons dans les plus brefs d&eacute;lais </span>
                     </div>
          </div>
        </div>
      </div>
    </div>
    
    
    
    <br><br><br>

    
    <div class="sub-footer">
      <div class="container">
        <div class="row">
          <div class="col-md-12">
            <p>Copyright &copy; <?php
      echo date("Y");      
            ?> Damweb Ltd.</a></p>
          </div>
        </div>
      </div>
    </div>

    <!-- Bootstrap core JavaScript -->
    <script src="vendor/jquery/jquery.min.js"></script>
    <script src="vendor/bootstrap/js/bootstrap.bundle.min.js"></script>

    <!-- Additional Scripts -->
    <script src="assets/js/custom.js"></script>
    <script src="assets/js/owl.js"></script>
    <script src="assets/js/slick.js"></script>
    <script src="assets/js/accordions.js"></script>

    <script language = "text/Javascript"> 
      cleared[0] = cleared[1] = cleared[2] = 0; //set a cleared flag for each field
      function clearField(t){                   //declaring the array outside of the
      if(! cleared[t.id]){                      // function makes it static and global
          cleared[t.id] = 1;  // you could use true and false, but that's more typing
          t.value='';         // with more chance of typos
          t.style.color='#fff';
          }
      }
    </script>
    
    <?php
 if($_GET['finish'] == 1){
echo "<script>
	document.getElementById('divHide1').style = 'display:none';
	document.getElementById('divHide2').style = 'display:none';
	document.getElementById('divHide3').style = '';
	</script>";
 }else{
 echo '';
 }
 
 ?>
    
    
<script>
	var checkvalue = document.getElementById('check_amount');
	var liTotal = document.getElementById('li_total');
	var liExtra1 = document.getElementById('li_extra1');
	var liExtra2 = document.getElementById('li_extra2');
	var liExtra2value = document.getElementById('extra');
	var butt0n = document.getElementById('butt0n');
	var inExtra1 = document.getElementById('inExtra1');
	var n4me = document.getElementById('n4me');
	var inExtra2 = document.getElementById('inExtra2');
	var inExtra3 = document.getElementById('inExtra3');
	var divHide1 = document.getElementById('divHide1');
	var divHide2 = document.getElementById('divHide2');
	var butt0n2 = document.getElementById('butt0n2');
	function checkprice1(pricetoadd,pricemonth,name){
	liTotal.style = "";
	butt0n2.style = "";
	inExtra1.value = name;
	n4me.innerHTML = name;
	inExtra2.value = pricetoadd + pricemonth;
	butt0n.style = "";
	liExtra1.innerHTML = name;
	liTotal.innerHTML =  pricetoadd + ',00$' + ' + ' + pricemonth + ',00$ / month</li>';
	checkvalue.innerHTML = pricemonth + pricetoadd + ',00$<i class="fa fa-angle-right"></i>';
	}
	
	function checkprice2(pricetoadd,name){
	butt0n2.style = "";
	liExtra2.style = "display:none";
	liTotal.style = "";
	inExtra1.value = name;
	n4me.innerHTML = name;
	inExtra2.value = pricetoadd;
	butt0n.style = "";
	liExtra1.innerHTML = name;
	liTotal.innerHTML = pricetoadd + ',00$';
	liExtra2.innerHTML = '';
	checkvalue.innerHTML = pricetoadd + ',00$<i class="fa fa-angle-right"></i>';
	}
	
	function checkprice3(pricemonth,name){
	butt0n2.style = "";
	liExtra2.style = "display:none";
	liTotal.style = "";
	inExtra1.value = name;
	n4me.innerHTML = name;
	inExtra2.value = pricemonth;
	butt0n.style = "";
	liExtra1.innerHTML = name;
	liTotal.innerHTML = pricemonth + ',00$ / month';
	liExtra2.innerHTML = "";
	checkvalue.innerHTML = pricemonth + ',00$<i class="fa fa-angle-right"></i>';
	}
	function hide1ToHide2() {
	divHide1.style = "display:none";
	divHide2.style = "";
	}
	function hide2ToHide1() {
	divHide1.style = "";
	divHide2.style = "display:none";
	}
	</script>
  </body>
</html><?php 

}else{
  echo "<script>window.location = '../index.php'</script>";
}
?>