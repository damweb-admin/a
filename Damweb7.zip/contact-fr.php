<?php
session_start();
?>

<!DOCTYPE html>
<html lang="fr">

  <head>

    <meta charset="utf-8">
    	
    	<link rel="apple-touch-icon-precomposed" sizes="57x57" href="favicon/apple-touch-icon-57x57.png" />
<link rel="apple-touch-icon-precomposed" sizes="114x114" href="favicon/apple-touch-icon-114x114.png" />
<link rel="apple-touch-icon-precomposed" sizes="72x72" href="favicon/apple-touch-icon-72x72.png" />
<link rel="apple-touch-icon-precomposed" sizes="144x144" href="favicon/apple-touch-icon-144x144.png" />
<link rel="apple-touch-icon-precomposed" sizes="60x60" href="favicon/apple-touch-icon-60x60.png" />
<link rel="apple-touch-icon-precomposed" sizes="120x120" href="favicon/apple-touch-icon-120x120.png" />
<link rel="apple-touch-icon-precomposed" sizes="76x76" href="favicon/apple-touch-icon-76x76.png" />
<link rel="apple-touch-icon-precomposed" sizes="152x152" href="favicon/apple-touch-icon-152x152.png" />
<link rel="icon" type="image/png" href="favicon.ico" />
<meta name="application-name" content="&nbsp;"/>
<meta name="msapplication-TileColor" content="#FFFFFF" />
<meta name="msapplication-TileImage" content="favicon/mstile-144x144.png" />
<meta name="msapplication-square70x70logo" content="favicon/mstile-70x70.png" />
<meta name="msapplication-square150x150logo" content="favicon/mstile-150x150.png" />
<meta name="msapplication-wide310x150logo" content="favicon/mstile-310x150.png" />
<meta name="msapplication-square310x310logo" content="favicon/mstile-310x310.png" />
<meta property="og:type"  content="website" />
<meta property="og:title"  content="Damweb" />
<meta property="og:description" content="Conception et d&eacute;veloppement de site Web s&eacute;curis&eacute; ">
<meta property="fb:app_id" content='763669451252283'>
<meta property="og:image"  content="https://damweb.ca/assets/images/logo-fr.png">
<meta property="og:url" content="https://damweb.ca/contact-fr.php" >
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
<meta name="Description" CONTENT="Besoin d'un site Web s&ucirc;r et s&eacute;curis&eacute;? Besoin de s&eacute;curiser votre propre site? Nous sommes l&agrave; pour vous! Gr&acirc;ce &agrave; notre connaissance du cryptage et de plusieurs langages Web, Damweb se fera un plaisir de d&eacute;velopper votre site et / ou de le rendre plus s&eacute;curis&eacute;.">
    <meta name="author" content="Damweb">
    <link href="https://fonts.googleapis.com/css?family=Poppins:100,200,300,400,500,600,700,800,900&display=swap" rel="stylesheet">
    <title>Contactez-Nous | Concepteur Web S&eacute;curis&eacute; Damweb</title>

    <!-- Bootstrap core CSS -->
    <link href="vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">

    <!-- Additional CSS Files -->
    <link rel="stylesheet" href="assets/css/fontawesome.css">
    <link rel="stylesheet" href="assets/css/templatemo-finance-business.css">
    <link rel="stylesheet" href="assets/css/owl.css">
  </head>

  <body>

    <!-- ***** Preloader Start ***** -->
    <div id="preloader">
        <div class="jumper">
            <div></div>
            <div></div>
            <div></div>
        </div>
    </div>  
    <!-- ***** Preloader End ***** -->

    <!-- Header -->
    
    <header class="">
      <nav class="navbar navbar-expand-lg">
        <div class="container">
          <a class="navbar-brand" href="index.php"><h2>Damweb</h2></a>
            <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarResponsive" aria-controls="navbarResponsive" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
          </button>
          <div class="collapse navbar-collapse" id="navbarResponsive">
            <ul class="navbar-nav ml-auto">
              <li class="nav-item">
                <a class="nav-link" href="index-fr.php">Accueil
                </a>
              
                	           <li class="nav-item">
                <a class="nav-link" href="services-fr.php">Nos Services</a>
              </li>
                
                </li>
              <li class="nav-item active ">
                <a class="nav-link" href="">Contactez-nous</a>
                       <span class="sr-only">(current)</span>
              </li>
   
              <li class="nav-item">
                <a class="nav-link" href="contact-en.php">English</a>
              </li>
            </ul>
          </div>
        </div>
      </nav>
    </header>

    <!-- Page Content -->
    <!-- Banner Starts Here -->
    <div class=" header-text" id="top">
        <div class="Modern-Slider">
        </div>
    </div>
   
    	    <!-- Banner Ends Here -->
    	
     <div class="page-heading header-text">
      <div class="container">
        <div class="row">
          <div class="col-md-12">
            <h1>Contactez-nous</h1>
            <span>n'h&eacute;sitez pas &agrave; nous envoyer un message maintenant!</span>
          </div>
        </div>
      </div>
    </div>

    <div class="contact-information">
      <div class="container">
        <div class="row">
          <div class="col-md-4">
            <div class="contact-item">
              <i class="fa fa-phone"></i>
              <h4>T&eacute;l&eacute;phone</h4>
             <a href="tel:+1-438-275-3753">+1 (438) 275-3753</a>
            </div>
          </div>
          <div class="col-md-4">
            <div class="contact-item" onclick="window.location = 'mailto:damweb.info@gmail.com'">
              <i class="fa fa-envelope"></i>
              <h4>Email</h4>
              <a>cliquer pour envoyer</a>
            </div>
          </div>
          <div class="col-md-4">
            <div class="contact-item">
              <i class="fa fa-user-plus"></i>
              <h4>Facebook</h4>
              <a href="https://facebook.com/damweb.info">@damweb.info</a>
            </div>
          </div>
        </div>
      </div>
    </div>
<?php
    if($_SESSION['on'] == 'on'){
?>
    <div class="callback-form contact-us">
      <div class="container">
        <div class="row">
          <div class="col-md-12">
            <div class="section-heading">
              <h2>Envoyez-nous un <em>message</em></h2>
              <span></span>
            </div>
          </div>
          <div class="col-md-12">
            <div class="contact-form">
           <form id="contact" action="try/try_comment.php" method="post">
           <input type="hidden" name="link" value="contact-fr.php">
                <div class="row">
                  <div class="col-lg-4 col-md-12 col-sm-12">
                    <fieldset>
                      <input name="name" type="text" class="form-control" id="name" placeholder="Nom Complet" required="">
                    </fieldset>
                  </div>
                  <div class="col-lg-4 col-md-12 col-sm-12">
                    <fieldset>
                      <input name="email" type="email" class="form-control" id="email" placeholder="Addresse e-mail" required="">
                    </fieldset>
                  </div>
                  <div class="col-lg-4 col-md-12 col-sm-12">
                    <fieldset>
                      <input name="subject" type="text" class="form-control" id="subject" placeholder="Sujet" required="">
                    </fieldset>
                  </div>
                  <div class="col-lg-12">
                    <fieldset>
                      <textarea name="message" rows="6" class="form-control" id="message" placeholder="Votre Message" required=""></textarea>
                    </fieldset>
                  </div>
                       
<?php
	
	if($_SESSION['c0unt'] > 3){
	echo "<div class='col-lg-4 col-md-12 col-sm-12'><fieldset>";
	  if($_GET['err'] == 'badcapcha'){
	    echo "<p>Bad capcha</p>";
	  }else{echo "";}
echo "<img src='try/photo.php' width='103' style='border-radius: 10%;'><hr><input name='form_capcha' type='text' class='form-control' id='subject' placeholder='Entrez le Code' required=''>";
	}else{
	echo "";
	} ?>
                  
                  
                  <div class="col-lg-12">
                    <fieldset>
                      <button type="submit" id="form-submit" class="filled-button">Envoyer</button>
                    </fieldset>
                  </div>
                </div>
              </form>
            </div>
          </div>
        </div>
      </div>
    </div>
    
    <?php
    }else{echo '';}
    ?>
  
    <br><br><br>

    
    <div class="sub-footer">
      <div class="container">
        <div class="row">
          <div class="col-md-12">
            <p>Propulsé par Damweb | <?php
      echo date("Y");      
            ?></a></p> 
                     <ul class="social-icons">
              <li><a href="https://twitter.com/damweb_ca"><i class="fa fa-twitter"></i></a></li>
              <li><a href="https://www.linkedin.com/events/damweb6764568766647951360"><i class="fa fa-linkedin"></i></a></li>
              <li><a href="https://www.facebook.com/damweb.info/"><i class="fa fa-facebook"></i></a></li>
              <li><a href="mailto:damweb.info@gmail.com"><i class="fa fa-google"></i></a></li>
              <li><a href="https://www.instagram.com/damweb.ca"><i class="fa fa-instagram"></i></a></li>
            </ul>
          </div>
        </div>
      </div>
    </div>

    <!-- Bootstrap core JavaScript -->
    <script src="vendor/jquery/jquery.min.js"></script>
    <script src="vendor/bootstrap/js/bootstrap.bundle.min.js"></script>

    <!-- Additional Scripts -->
    <script src="assets/js/custom.js"></script>
    <script src="assets/js/owl.js"></script>
    <script src="assets/js/slick.js"></script>
    <script src="assets/js/accordions.js"></script>

    <script language = "text/Javascript"> 
      cleared[0] = cleared[1] = cleared[2] = 0; //set a cleared flag for each field
      function clearField(t){                   //declaring the array outside of the
      if(! cleared[t.id]){                      // function makes it static and global
          cleared[t.id] = 1;  // you could use true and false, but that's more typing
          t.value='';         // with more chance of typos
          t.style.color='#fff';
          }
      }
    </script>

  </body>
</html>