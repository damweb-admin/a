<?php
session_start();
if($_SESSION['on'] == 'on'){
$ip = $_SERVER['REMOTE_ADDR'];
$time = date("Y/m/d h:i");
$inExtra1 = $_POST['inExtra1'];
$inExtra2 = $_POST['inExtra2'];
$inExtra3 = $_POST['inExtra3'];
$phone = $_POST['phone'];
$data = "Name: ".$_POST['name']."
Email: ".$_POST['email']."
Subject: ".$_POST['subject']."
Message: ".$_POST['message']."
Ip: $ip
Time: $time
$phone
$inExtra1
$inExtra2
$inExtra3

";
$mytxt = fopen("../question.txt", "a");




if($_SESSION['c0unt'] == ''){
  
$_SESSION['c0unt'] = 1 ;
              	if($_POST['email'] == ""){echo "";
              	}else{
        fwrite($mytxt, $data);}
        
}else{
if($_POST['form_capcha'] == ""){
$_SESSION['c0unt'] = $_SESSION['c0unt'] + 1;
        fwrite($mytxt, $data);
}else{
if($_SESSION['capC'] == $_POST['form_capcha']){
  $_SESSION['capC'] = "";
  $_SESSION['c0unt'] = "";
        fwrite($mytxt, $data);
  }else{
echo "<script>window.location = '../".$_POST['link']."?err=badcapcha'</script>";
    
  }}}
echo "<script>window.location = '../".$_POST['link']."'</script>";




}else{
  echo "<script>window.location = '../index.php'</script>";
}
?>