<?php
session_start();
$_SESSION['on'] = "on";
?>
<script>window.location = "index-fr.php";</script>