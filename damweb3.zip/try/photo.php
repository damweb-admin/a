<?php
session_start();
if($_SESSION['on'] == 'on'){
$cap_code = substr(md5(rand()), 6,5);
$_SESSION['capC'] = $cap_code;
$cap_code2 = $_SESSION['capC'];
$im = imagecreate(60, 20);
$bg = imagecolorallocate($im, 255, 255, 255);
$textcolor = imagecolorallocate($im, 55, 175, 55);
imagestring($im, 5, 8, 2, $cap_code2, $textcolor);
header('Content-type: image/png');
imagepng($im);
imagedestroy($im);
}else{
  echo "<script>window.location = '../index.php'</script>";
}
?>




















